
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useState, useRef, useEffect } from "react";
import * as THREE from "three";

const VanInterior = () => {
  return (
    <mesh position={[0, 1, 0]}>
      <boxGeometry args={[3.4, 2, 1.78]} />
      <meshStandardMaterial color="gray" wireframe />
    </mesh>
  );
};

const PackoutBox = ({ box, onDragEnd }) => {
  const meshRef = useRef();
  const dragging = useRef(false);
  const offset = useRef([0, 0, 0]);

  useFrame(({ mouse, camera, raycaster, scene }) => {
    if (!dragging.current || !meshRef.current) return;
    raycaster.setFromCamera(mouse, camera);
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -box.size[1] / 2);
    const point = new THREE.Vector3();
    raycaster.ray.intersectPlane(plane, point);

    // Grid snapping
    const snappedX = Math.round(point.x / 0.1) * 0.1;
    const snappedZ = Math.round(point.z / 0.1) * 0.1;
    meshRef.current.position.x = snappedX;
    meshRef.current.position.z = snappedZ;
  });

  return (
    <group
      ref={meshRef}
      position={box.position}
      onPointerDown={(e) => {
        dragging.current = true;
        offset.current = [
          e.point.x - box.position[0],
          0,
          e.point.z - box.position[2],
        ];
      }}
      onPointerUp={() => {
        dragging.current = false;
        onDragEnd(meshRef.current.position.toArray());
      }}
    >
      <mesh>
        <boxGeometry args={box.size} />
        <meshStandardMaterial color="red" />
      </mesh>
    </group>
  );
};

const Ruler = () => {
  const lines = [];
  for (let i = -1.7; i <= 1.7; i += 0.1) {
    lines.push(
      <line key={`line-${i}`}>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            count={2}
            array={new Float32Array([i, 0, -0.89, i, 0, 0.89])}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="black" />
      </line>
    );
  }
  return <>{lines}</>;
};

export default function App() {
  const [boxes, setBoxes] = useState([
    { position: [0, 0.08, 0], size: [0.561, 0.165, 0.411], label: "Standard" }
  ]);

  const addBox = () => {
    const sizes = [
      { size: [0.561, 0.165, 0.411], label: "Standard" },
      { size: [0.561, 0.33, 0.411], label: "Tall" },
      { size: [0.28, 0.165, 0.411], label: "Half Width" }
    ];
    const random = sizes[Math.floor(Math.random() * sizes.length)];
    setBoxes((prev) => [
      ...prev,
      {
        position: [Math.random() * 2 - 1, 0.08, Math.random() * 1 - 0.5],
        size: random.size,
        label: random.label
      }
    ]);
  };

  const updateBoxPosition = (idx, newPos) => {
    setBoxes((prev) => {
      const updated = [...prev];
      updated[idx] = { ...updated[idx], position: newPos };
      return updated;
    });
  };

  const saveLayout = () => {
    const data = JSON.stringify(boxes);
    localStorage.setItem("packoutLayout", data);
    alert("Tasarım kaydedildi!");
  };

  const loadLayout = () => {
    const data = localStorage.getItem("packoutLayout");
    if (data) setBoxes(JSON.parse(data));
  };

  return (
    <div className="w-full h-screen">
      <Canvas camera={{ position: [4, 3, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} />
        <VanInterior />
        <Ruler />
        {boxes.map((box, idx) => (
          <PackoutBox
            key={idx}
            box={box}
            onDragEnd={(pos) => updateBoxPosition(idx, pos)}
          />
        ))}
        <OrbitControls />
      </Canvas>
      <div className="absolute top-4 left-4 space-y-2">
        <button onClick={addBox} className="bg-black text-white px-4 py-2 rounded-xl shadow">
          PACKOUT Ekle
        </button>
        <button onClick={saveLayout} className="bg-blue-600 text-white px-4 py-2 rounded-xl shadow">
          Kaydet
        </button>
        <button onClick={loadLayout} className="bg-green-600 text-white px-4 py-2 rounded-xl shadow">
          Yükle
        </button>
        <p className="bg-white p-2 rounded shadow text-sm max-w-xs">
          • Sürükle bırak aktif<br />
          • Grid snapping ile hizalama<br />
          • Farklı boyut ve etiketlerde kutular<br />
          • Üst üste koymak için y koordinatını manuel artır (otomatik stack eklenecek)<br />
          • Kaydet/Yükle ile düzenini sakla!
        </p>
      </div>
    </div>
  );
}
